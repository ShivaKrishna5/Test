function Register() {
  return <>In register</>;
}

export default Register;
