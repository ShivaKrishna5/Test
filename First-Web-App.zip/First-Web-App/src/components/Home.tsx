import React from "react";
import { useLocation } from "react-router-dom";
import Header from "./Header";
function Home() {
  const location = useLocation();
  console.log(location.state);
  if (location.state) {
    const LoggedUserContext = React.createContext(location.state);
    return (
      <>
        <LoggedUserContext.Provider value={location.state}>
          <Header />
        </LoggedUserContext.Provider>
      </>
    );
  } else {
    return <Header />;
  }
}

export default Home;
