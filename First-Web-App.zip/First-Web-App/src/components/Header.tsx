function Header() {
  const applicationName = "KASH0622";
  const assignments = ["Tic Tac Toe"];
  const navItems = [
    {
      name: "Assignments",
      type: "text",
      options: assignments,
    },
  ];
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a className="navbar-brand ms-2" href="#">
          {applicationName}
        </a>
        <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
          {navItems.map((item, i) => (
            <li key={i} className="nav-item">
              <a className="nav-link" href="#">
                {item.name}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}

export default Header;
